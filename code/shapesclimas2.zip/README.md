This folder contains the climate-region shapefiles used to compute climate-sector averages.
The scripts expect shapefiles named s1.shp, s2.shp, s3.shp, s4.shp, and s5.shp.
To adapt the workflow, replace these shapefiles and update the corresponding shape names,
coordinate reference system, and region labels in the climate-region scripts.